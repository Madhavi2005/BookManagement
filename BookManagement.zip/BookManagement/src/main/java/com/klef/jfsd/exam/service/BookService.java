package com.klef.jfsd.exam.service;

import com.klef.jfsd.exam.model.Book;
import com.klef.jfsd.exam.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    /**
     * Updates the details of a book with the given ID.
     *
     * @param id          the ID of the book to update
     * @param bookDetails the new details for the book
     * @return an Optional containing the updated book, or empty if the book is not found
     */
    public Optional<Book> updateBook(Long id, Book bookDetails) {
        // Fetch the existing book by ID
        return bookRepository.findById(id).map(existingBook -> {
            // Update the fields with new details
            existingBook.setTitle(bookDetails.getTitle());
            existingBook.setAuthor(bookDetails.getAuthor());
            existingBook.setGenre(bookDetails.getGenre());
            existingBook.setPrice(bookDetails.getPrice());
            existingBook.setPublishedYear(bookDetails.getPublishedYear());

            // Save and return the updated book
            return bookRepository.save(existingBook);
        });
    }
}

