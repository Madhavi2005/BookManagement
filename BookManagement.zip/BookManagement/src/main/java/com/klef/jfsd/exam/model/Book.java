package com.klef.jfsd.exam.model;

public class Book {

	public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

}
